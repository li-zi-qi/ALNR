clear
clc
close all

load('data\AR.mat');

% -------------------------------------------------------------------------

par.nClass = length(unique(trainlabels));
dim = [54 120 300];

lambda = 1e-4;
mu= 1e-2;
sigma = 1e-1;

%--------------------------------------------------------------------------

Tr_DAT = double(NewTrain_DAT(:, trainlabels<=par.nClass));
trls = trainlabels(trainlabels<=par.nClass);
Tt_DAT = double(NewTest_DAT(:, testlabels<=par.nClass));
ttls = testlabels(testlabels<=par.nClass);

train_tol = size(Tr_DAT,2);
test_tol = size(Tt_DAT,2);
ClassNum = par.nClass;

%--------------------------------------------------------------------------

reg_rate = zeros(1, length(dim));
kk = 1;

param = [];
param.mu = mu;
param.lambda = lambda;
param.sigma = sigma;

%-------------------------------------------------------------------------

for eigen_num = dim
    
    [disc_set, disc_value, Mean_Image] = Eigenface_f(Tr_DAT, eigen_num);  % Eigenface extracting
    tr_dat  =  disc_set'*Tr_DAT;
    tt_dat  =  disc_set'*Tt_DAT;
    tr_dat = normc(tr_dat);
    tt_dat = normc(tt_dat);

    ID = zeros(1,test_tol);
    X = tr_dat;
    
    %-------------------------------------------------------------------------
    
    parfor i = 1:test_tol
        y = tt_dat(:, i);
        [z, alpha] = ALNR(X, y, param);
        
        W = sparse([], [], [], train_tol, ClassNum, length(alpha));

        for j=1:ClassNum
            ind = (j==trls);
            W(ind,j) = alpha(ind);
        end
        
        temp = X * W - repmat(y, 1, ClassNum);
        residual = sqrt(sum(temp.^2));

        [~,index] = min(residual);
        ID(i) = index;
    end
    
    %-------------------------------------------------------------------------
    
    cornum = sum(ID==ttls);
    reg_rate(kk) = cornum / length(ttls); % classification accuracy
    kk = kk + 1;
    
    fprintf('dim = %d, acc = %.1f%% \n', eigen_num, reg_rate(kk-1) * 100);
end
