function [z,alpha] = ALNR(X, y, param)
[~,n] = size(X);

tol = 1e-5;
maxIter = 5;

mu = param.mu;
sigma = param.sigma;
lambda = param.lambda;

z = zeros(n,1);
alpha = zeros(n,1);
l = zeros(n,1);

XTX = X'*X;
XTy = X'*y;
iter = 0;

dist1 = bsxfun(@minus,X,y);
dist2 = sqrt(sum(dist1.^2));

dist2 = dist2-max(dist2);
dist = exp(dist2/sigma);

D = diag(dist.^2);

temp_X = XTX+lambda*D+mu/2*eye(n);

while iter<maxIter
    iter = iter + 1;
    
    z_k = z;
    alpha_k = alpha;
    
    alpha = temp_X\(XTy+mu/2*z+l/2);
    
    z_temp = alpha-l/mu;
    z = EProjSimplex_new(z_temp, 1);
    
    leq1 = z-alpha;
    leq2 = z-z_k;
    leq3 = alpha-alpha_k;
    stopC1 = max(norm(leq1),norm(leq2));
    stopC = max(stopC1,norm(leq3));
    
    if stopC<tol || iter>=maxIter
        break;
    else
        l = l + mu*leq1;
    end
end